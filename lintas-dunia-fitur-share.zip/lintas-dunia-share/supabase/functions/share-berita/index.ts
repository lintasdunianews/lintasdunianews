import { serve } from "https://deno.land/std@0.224.0/http/server.ts";

const esc = (v: unknown) => String(v ?? "").replace(/[&<>"']/g, (c) => ({
  "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
}[c]!));
const plain = (v: unknown, max = 220) => String(v ?? "").replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim().slice(0, max);

serve(async (req) => {
  const url = new URL(req.url);
  const id = url.searchParams.get("id");
  const siteParam = url.searchParams.get("site") || "https://lintasdunianews.github.io/lintasdunianews/";
  let site = "https://lintasdunianews.github.io/lintasdunianews/";
  try {
    const candidate = new URL(siteParam);
    if (candidate.protocol === "https:" && candidate.hostname === "lintasdunianews.github.io") site = candidate.toString();
  } catch { /* use safe default */ }
  if (!id) return new Response("ID berita tidak ditemukan", { status: 400 });

  const supabaseUrl = Deno.env.get("SUPABASE_URL");
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!supabaseUrl || !serviceKey) return new Response("Konfigurasi server belum lengkap", { status: 500 });

  const api = new URL(`${supabaseUrl}/rest/v1/berita`);
  api.searchParams.set("id", `eq.${id}`);
  api.searchParams.set("select", "id,judul,kategori,penulis,foto,isi");
  const response = await fetch(api, { headers: { apikey: serviceKey, Authorization: `Bearer ${serviceKey}` } });
  if (!response.ok) return new Response("Berita tidak dapat diambil", { status: 502 });
  const rows = await response.json();
  const news = rows?.[0];
  if (!news) return new Response("Berita tidak ditemukan", { status: 404 });

  const title = plain(news.judul || "Berita LINTAS DUNIA NEWS", 180);
  const description = plain(news.isi || news.kategori || "Baca berita selengkapnya di LINTAS DUNIA NEWS.", 220);
  const imageUrl = /^https:\/\//i.test(news.foto || "") ? news.foto : "";
  const destination = new URL(site);
  destination.searchParams.set("berita", String(news.id));
  const canonical = url.toString();
  const html = `<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>${esc(title)} | LINTAS DUNIA NEWS</title>
<meta name="description" content="${esc(description)}">
<meta property="og:type" content="article"><meta property="og:site_name" content="LINTAS DUNIA NEWS"><meta property="og:title" content="${esc(title)}"><meta property="og:description" content="${esc(description)}"><meta property="og:url" content="${esc(canonical)}">${imageUrl ? `<meta property="og:image" content="${esc(imageUrl)}"><meta property="og:image:secure_url" content="${esc(imageUrl)}"><meta property="og:image:alt" content="${esc(title)}">` : ""}
<meta name="twitter:card" content="${imageUrl ? "summary_large_image" : "summary"}"><meta name="twitter:title" content="${esc(title)}"><meta name="twitter:description" content="${esc(description)}">${imageUrl ? `<meta name="twitter:image" content="${esc(imageUrl)}">` : ""}
<meta http-equiv="refresh" content="0;url=${esc(destination.toString())}"></head><body><p>Membuka berita di <a href="${esc(destination.toString())}">LINTAS DUNIA NEWS</a>…</p><script>location.replace(${JSON.stringify(destination.toString())})</script></body></html>`;
  return new Response(html, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "public, max-age=300" } });
});
